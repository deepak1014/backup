<div class="container">
@extends('layout.navigation')

<div class="header">
<img src="header.jpg" height="270px" width=1000px style="margin-left:70px;">

</div>
<p id="about_us">About Us</h2>
<hr>
<div class="row">
<div class="col-sm-8" >
<img src="\bootstrap\css\image1.jpeg" height="100px"  width="100px" style="float:left;margin-left:70px;" >

@foreach($information as $matter)
<p id="about">{{$matter->text}}
@endforeach</p>
</div>
</div>
<div class="row">
<div class="col-sm-8">
@foreach($information as $matter)
<p id="about">{{$matter->text}}
@endforeach</p>
</div>
</div>
<hr>
