@extends('layout.navigation')
<div  class="container">
<div class="header">
<img src="header.jpg" height="270px" width=1000px style="margin-left:70px;">

</div>
<p id="programme" >University Offers Various Programme</p>
<hr>
<div class="row" id="different_programme">
<div class="col-sm-4"><br/>
<p>Informatioin Technology Programme</p>
BCA<br/>
MCA<br/>
PGDCA<br/>
MSC(CS)<br/>
MSC(IT)
</div>
<div class="col-sm-4"><br/>
<p>Management Programme</p>
BBA<br/>
MBA
</div>
<div class="col-sm-4"><br/>
<p>Certificate Course</p>
Certificate in Language<br/>
Certificate in journalism
</div>
</div>
<hr>
<div class="row" id="different_programme">
<div class="col-sm-4">
<p>Arts </p>
B.A<br/>
M.A
</div>
<div class="col-sm-4">
<p>Science</p>
M.SC
</div>
<div class="col-sm-4">
<p>Commerce</p>
B.Com<br/>
M.Com
</div>
</div>
<hr>