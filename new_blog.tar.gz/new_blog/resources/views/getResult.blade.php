<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body id="form_background_color">
@extends('layout.navigation')<br/>
<div class="container">
<
<div class="jumbotron">
<table border="1px" align="center" width="570px" height="50px" >
<tr>
<th style="text-align:center" >Roll Number</th>
<th style="text-align:center">Student Name</th>
<th style="text-align:center">Rapid English</th>
<th style="text-align:center">English Grammer</th>
<th style="text-align:center">Total</th>
</tr>
<tr style="text-align:center">
<td>{{$information->id}}</td>
<td>{{$information->s_name}}</td>
<td>{{$information->rapid_english}}</td>
<td>{{$information->english_grammer}}</td>

<?php
$a=$information->rapid_english;
$c=$information->english_grammer;
$total=$a+$c;?>
<td><?php echo $total;?></td>
</tr>
</table>
</div>
</div>


