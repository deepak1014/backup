@extends('layout.navigation')
<div class="container">
<div class="header">

<img src="header.jpg" height="270px" width=1000px style="margin-left:70px;">
</div>
<hr>

<div class="row" id="home_text">
<div class="col-sm-4">
<p>Chancellor Message</p>
@foreach($information as $text)
<p id="left_text">"{{$text->left_text}}"</p>
@endforeach
</div>
<div class="col-sm-4">
<p>NEWS AND UPDATES</p>
<marquee direction="up" scrolldelay="200" height="100px" width="300px"><p id="middle_text"><a href="/result">M.A (English) previews result is declared<br/> M.A (English) final result is declared<br/>M.A (Hindi) previous result is declared<br/>M.A (Hindi) final result is declared</p></a></marquee>
</div>
<div class="col-sm-4" >
<p>About The University</p>
@foreach($information as $text)
<p id="right_text">"{{$text->right_text}}"</p>
@endforeach
</div>
</div>
<hr>
<div class="row" id="home_text">
<div class="col-sm-4">
<p>Vice Chancellor Message</p>
@foreach($information as $text)
<p id="left_text">"{{$text->left_text}}"</p>
@endforeach
</div>
<div class="col-sm-4">
<p>World Class Environment</p>
@foreach($information as $text)
<p id="left_text">"{{$text->left_text}}"</p>
@endforeach
</div>
<div class="col-sm-4">
<p>Facts About The University</p>
@foreach($information as $text)
<p id="right_text">"{{$text->right_text}}"</p>
@endforeach
</div>

</div>
<hr>
