<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
@extends('layout.navigation')
<div class="container" id="student_activities">
<p style="color:#6495ED" class="text-center">Student Activities At University</p>
<hr>
@foreach($information as $text)

<img src="bootstrap\css\{{$text->image}}" height="200px" width="200px" style="margin-top:14px;">&nbsp&nbsp&nbsp&nbsp
@endforeach
</div>
</div>