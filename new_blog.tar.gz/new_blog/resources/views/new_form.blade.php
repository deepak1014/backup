@extends('layout.navigation')
<html>
<head>
</script>
</head>
<div class="row" id="contact_form">
<div class="col-sm-4">
<form action="{{route('post_data')}}" method="post" enctype="multipart/form-data">
{!!csrf_field()!!}
<br/><br/>
<div class="panel panel-default" id="form_panel">
<div class="panel-body">
<p>fill the form </p>

<input type="text" name="name" class="form-control" placeholder="Name" required>

<br/>
<input type="text" name="email" class="form-control" placeholder="Email" required><br/>
<p style="margin-top:20px;font-size:14px">Gender :&nbsp&nbsp&nbsp&nbsp <label class="radio-inline"><input type="radio" style="margin-top:1px" name="gender" value="Male">Male</label>
<label class="radio-inline"><input type="radio" style="margin-top:1px" name="gender" value="female">Female<br/></label>
<p style="margin-top:20px;font-size:14px"> Select Language :&nbsp&nbsp&nbsp&nbsp<label class="checkbox-inline"><input type="checkbox" name="language[]" value="english">English</label>
<label class="checkbox-inline"><input type="checkbox" name="language[]" value="hindi">Hindi</label>
<br/><br/>
<select name="state">
<option value="rajasthan">Rajasthan</option>
<option value="madhya pradesh">Madhya Pradesh</option>
</select>
<input type="submit" name="submit" value="Enter" class="btn btn-primary" >
</form>
</div>
</div>