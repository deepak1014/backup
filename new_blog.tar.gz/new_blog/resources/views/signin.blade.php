<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body id="form_background_color">
@extends('layout.navigation')
<hr>
<div class="container">
<br/>

<div class="panel panel-default" id="form_panel">
<div class="panel-body">
@if($errors->any())
<center><p>{{$errors->first()}}</p></center>
@endif
<form action="{{route ('dosignin')}}" method="post" >
{!!csrf_field()!!}
<h4 class="text-center">Staff Login</h4><br/>
<input type="text" class="form-control" name="username" placeholder="Username" required><br/>
<input type="password" class="form-control" name="password" placeholder="Password" required><br/>
<center><input type="submit" name="submit" class="btn btn-primary" value="Sign In"></center><br/>
<p id="signup" class="text-center">New User : <a href="signup">Sign Up</a></p>
</form>
</div>
</div>