@extends('layout.navigation')
<div class="container" id="blog">
<div class="row">
<div class="col-sm-12">

@foreach($information as $text)
<h2><b>{{$text->blog_title}}</b></h2><br/>
<p style="font-size:17px;color:black; ">{{$text->blog_post}}{{$text->blog_post}}</p><br/>
<b>posted by :</b> {{$text->created_by}}<br/>
<b>date :</b>{{$text->created_at}}<br/>
@endforeach
</div>
</div>
</div>