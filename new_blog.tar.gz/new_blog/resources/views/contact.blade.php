@extends('layout.navigation')
<div class="container">
<div class="header"><img src="header.jpg" height="270px" width=1000px style="margin-left:70px;">
</div>
<hr>
<p id="main_contact">University Address</p>
<p id="contact">Mohali,Punjab<br/>
India<br/>
Contact Us On Email : hr_university@gmail.com
</p>
<div class="row" id="contact_form">
<div class="col-sm-4">
<form action="{{route ('dosignup')}}" method="post" enctype="multipart/form-data">
{!!csrf_field()!!}
<br/><br/>
<p>fill the form </p>
<input type="text" name="username" class="form-control" placeholder="Name" required>

<br/>
<input type="text" name="email" class="form-control" placeholder="Email" required><br/>
<input type="text" name="address" class="form-control" placeholder="Address" required><br/>

<input type="submit" name="submit" value="Enter" class="btn btn-primary" >
</form>
</div>
</div>
<hr>

