<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
Route::group(['middleware' => ['web']],function(){
Route::get('/','MainController@getHome');


Route::get('home',[
'uses'=>'MainController@getHome',
'as'=>'home'
	]);
Route::get('about',[
'uses'=>'MainController@getAbout',
'as'=>'about'
	]);
Route::get('programme',[
'uses'=>'MainController@getProgramme',
'as'=>'programme'
	]);

Route::get('student_activities',[
'uses'=>'MainController@getStudentactivities',
'as'=>'student_activities'
	]);
Route::get('result',[
'uses'=>'MainController@getDisplay',
'as'=>'result'
	]);
Route::get('total',[
'uses'=>'MainController@getResult',
'as'=>'total'
	]);

Route::get('signin',[
'uses'=>'MainController@showForm',
'as'=>'signin'
	]);
Route::post('dosignin',[
'uses'=>'MainController@postSignin',
'as'=>'dosignin'
	]);
Route::get('signout',[
'uses'=>'MainController@doSignout',
'as'=>'signout'
	]);
Route::get('signup',[
'uses'=>'MainController@showsignup',
'as'=>'signup'
	]);
Route::post('dosignup',[
'uses'=>'MainController@postSignup',
'as'=>'dosignup'
	]);
Route::get('contact',[
'uses'=>'MainController@getContact',
'as'=>'contact'
	]);

Route::get('blog',[
'uses'=>'MainController@getBlog',
'as'=>'blog'
	]);
Route::get('form',[
'uses'=>'MainController@getAdd',
'as'=>'form'
	]);
Route::get('online_form',[
'uses'=>'MainController@show_Online_form',
'as'=>'online_form'
	]);

Route::post('post_data',[
'uses'=>'MainController@get_data',
'as'=>'post_data'
	]);







});


