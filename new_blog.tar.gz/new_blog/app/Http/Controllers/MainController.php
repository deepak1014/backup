<?php



namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Hash;

use App\Http\Requests;

use App\Index;

use App\About;

use App\Student_Activities;

use App\User;

use App\English;

use App\Blog;

use App\Data;


class MainController extends Controller
{
    public function getHome()
    {
    	$data['information']=Index::all();
    	return view('home',$data);
    }
    public function getAbout()
    {
        $data['information']=About::all();
        return view('about',$data);
    }
    public function getServices()
    {
    	return view('services');
    }
    public function getProgramme()
    {
        return view('programme');
    }
    public function getStudentactivities()
    {
        $data['information']=Student_Activities::all();
        return view('student_activities',$data);
    }
    public function getDisplay()
    {
        $data['information']=English::all();
        return view('result',$data);
    }
    public function getResult(Request $request)
    {   
            
         $data['information']=English::find($request->id);
        return view('getResult',$data);   
    }
    public function showForm()
    {
        return view('signin');
    }
    public function showSignup()
    {
        return view('signup');
    }
    public function postSignup(Request $request)
    {
            $username=$request['username'];
            $password=Hash::make($request['password']);
           
            $email=$request['email'];

            $data=new User();
            $data->username=$username;
            $data->password=$password;
            $data->email=$email;
            $path=public_path('/upload');
            $name=base_convert(time(),10,36).'_'.$request->image->getClientOriginalName();
            $request->image->move($path,$name);
            $data->image=$name;
            $data->save();
            return redirect()->back();
    }

    public function postSignIn(Request $request)
    {
        $username=$request['username'];
        $password=$request['password'];
        
        
        
        if(Auth::attempt(['username'=>$username,'password'=>$password]))
        {
            return view('dashboard');
        }
        return Redirect()->back()->withErrors(['invalid username or password']);
    }
    public function doSignout()
    {
        \Auth::logout();
        return redirect('home');

    }

    public function getContact()
    {
        return view('contact');
    }
    public function getBlog()
    {
        $data['information']=Blog::all();
        return view('blog',$data);
    }
    public function getAdd(Request $request)

    {
        echo var_dump($request->all()); 
        return view('new_form');
    }
    public function show_Online_form()
    {   
        return view('new_form');
    }
    public function get_data(Request $request)
    {

        $data=new Data();

        $data->name=$request->name;
        $data->email=$request->email;
        $data->gender=$request->gender;
        $data->language=implode(",",$request->language);
        $data->state=$request->state;
        $data->save();

    }

}



 