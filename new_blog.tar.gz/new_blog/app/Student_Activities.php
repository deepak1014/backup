<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student_Activities extends Model
{
    protected $table="Student_Activities";
}
