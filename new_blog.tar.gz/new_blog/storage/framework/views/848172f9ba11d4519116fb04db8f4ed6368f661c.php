<div class="container" id="blog">
<div class="row">
<div class="col-sm-12">

<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<h2><b><?php echo e($text->blog_title); ?></b></h2><br/>
<p style="font-size:17px;color:black; "><?php echo e($text->blog_post); ?><?php echo e($text->blog_post); ?></p><br/>
<b>posted by :</b> <?php echo e($text->created_by); ?><br/>
<b>date :</b><?php echo e($text->created_at); ?><br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
</div>
</div>
<?php echo $__env->make('layout.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>