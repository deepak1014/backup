<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
<link href="\font-awesome\css\font-awesome.css" rel="stylesheet">
<link href="\font-awesome\css\font-awesome.min.css" rel="stylesheet">
<nav class="navbar navbar-inverse navbar-fixed-top">  
    <div class="navbar-header">
      <a class="navbar-brand" href="">University Website</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home">Home</a></li>
      <li><a href="about">About</a></li>
      <li><a href="programme">Programme</a></li>
      <li><a href="student_activities">Student Activities</a></li>
      <li><a href="result">Result</a></li>
      <li><a href="signin">Staff Login</a></li>
      <li><a href="blog">Blog</a></li>
      <li><a href="contact">Contact</a></li>
      <li><a href="online_form">Online Form</a></li>
      
      
    </ul>
    
  </div>
</nav>

