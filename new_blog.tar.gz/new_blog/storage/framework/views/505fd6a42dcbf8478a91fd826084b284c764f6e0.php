<div class="container">


<div class="header">
<img src="header.jpg" height="270px" width=1000px style="margin-left:70px;">

</div>
<p id="about_us">About Us</h2>
<hr>
<div class="row">
<div class="col-sm-8" >
<img src="\bootstrap\css\image1.jpeg" height="100px"  width="100px" style="float:left;margin-left:70px;" >

<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matter): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<p id="about"><?php echo e($matter->text); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?></p>
</div>
</div>
<div class="row">
<div class="col-sm-8">
<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matter): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<p id="about"><?php echo e($matter->text); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?></p>
</div>
</div>
<hr>

<?php echo $__env->make('layout.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>