<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>

<div class="container" id="student_activities">
<p style="color:#6495ED" class="text-center">Student Activities At University</p>
<hr>
<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

<img src="bootstrap\css\<?php echo e($text->image); ?>" height="200px" width="200px" style="margin-top:14px;">&nbsp&nbsp&nbsp&nbsp
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
</div>
<?php echo $__env->make('layout.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>