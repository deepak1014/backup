<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body>
<div class="container">
<div class="row">
<h2>Share Your Thoughts On Different Topics</h2>
<p><b>if you are new user,sign up and already registered with us,sign in </b></p>
<b><a href="/">Sign Up<i class="fa fa-user-plus" aria-hidden="true"></i>
</a>
<a href="/showform">Sign In</a></b>