<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
<div class="container" id="dashboard">
<div class="row">
<div class="col-sm-4">
<p id="signin">Welcome <br/><?php echo e(Auth::user()->username); ?>

</p><a href="<?php echo e(route('signout')); ?>"><p id="signout">Sign Out</p></a>
<img src="\upload\<?php echo e(Auth::user()->image); ?>" height="100px" width="100px">
</div>
<div class="col-sm-4">
<br/><br/><p>University is organizing a tour in coming year</p>
</div>