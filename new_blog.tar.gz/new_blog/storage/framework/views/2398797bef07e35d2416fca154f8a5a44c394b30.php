<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body id="form_background_color">
<div class="container">

<hr>

<div class="panel panel-default" id="form_panel">
<div class="panel-body">
<form action="<?php echo e(route ('dosignup')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<h4 class="text-center">Only Staff Member Register Here</h4><br/>
<input type="text" name="username" class="form-control" placeholder="Username" required>

<br/>
<input type="password" name="password" class="form-control" placeholder="Password" required><br/>
<input type="text" name="email" class="form-control" placeholder="Email" required><br/>
<center><input type="file" name="image"><br/></center>
<center><input type="submit" name="submit" value="Sign Up" class="btn btn-primary" ></center>
</form>
<center><a href="<?php echo e(route('signin')); ?>">Sign In</a></center>
</div>

<span class="glyphicon glyphicon-" aria-hidden="true"></span>

<?php echo $__env->make('layout.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>