<div class="container">
<div class="header">

<img src="header.jpg" height="270px" width=1000px style="margin-left:70px;">
</div>
<hr>

<div class="row" id="home_text">
<div class="col-sm-4">
<p>Chancellor Message</p>
<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<p id="left_text">"<?php echo e($text->left_text); ?>"</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="col-sm-4">
<p>NEWS AND UPDATES</p>
<marquee direction="up" scrolldelay="200" height="100px" width="300px"><p id="middle_text"><a href="/result">M.A (English) previews result is declared<br/> M.A (English) final result is declared<br/>M.A (Hindi) previous result is declared<br/>M.A (Hindi) final result is declared</p></a></marquee>
</div>
<div class="col-sm-4" >
<p>About The University</p>
<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<p id="right_text">"<?php echo e($text->right_text); ?>"</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
</div>
<hr>
<div class="row" id="home_text">
<div class="col-sm-4">
<p>Vice Chancellor Message</p>
<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<p id="left_text">"<?php echo e($text->left_text); ?>"</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="col-sm-4">
<p>World Class Environment</p>
<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<p id="left_text">"<?php echo e($text->left_text); ?>"</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="col-sm-4">
<p>Facts About The University</p>
<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<p id="right_text">"<?php echo e($text->right_text); ?>"</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>

</div>
<hr>

<?php echo $__env->make('layout.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>