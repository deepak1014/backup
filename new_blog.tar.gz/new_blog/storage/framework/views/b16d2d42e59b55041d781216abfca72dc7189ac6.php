<br/><br/><br/><br/>
<div class="container">
<div class="row">
<div class="col-sm-8">
<div class="jumbotron">
<table border="1px" align="center">
<tr>
<th>Roll Number</th>
<th>Student Name</th>
<th>Rapid English</th>
<th>English Grammer</th>
<th>Total</th>
</tr>
<tr style="text-align:center">
<td><?php echo e($information->id); ?></td>
<td><?php echo e($information->s_name); ?></td>
<td><?php echo e($information->rapid_english); ?></td>
<td><?php echo e($information->english_grammer); ?></td>

<?php
$a=$information->rapid_english;
$c=$information->english_grammer;
$total=$a+$c;?>
<td><?php echo $total;?></td>

</div>
</div>
</div>
</div>



<?php echo $__env->make('layout.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>