<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body id="form_background_color">

<hr>

<br/>
<div class="container">
<div class="row">
<div  class="panel panel-default" id="form_panel">
<div class="panel-body">
<form action="<?php echo e(route ('total')); ?>">
<center><p>Enter Roll Number</p></center>
<input type="text" name="id" class="form-control" placeholder="Roll Number" required><br/>
<center><input type="submit" name="submit" value="Enter" class="btn btn-primary" ></center>
</form>
</div>
<?php echo $__env->make('layout.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>