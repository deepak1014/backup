<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
*/
Route::group(['middleware' => ['web']],function(){
Route::get('/', function () {
    return view('main');

});
Route::get('file',[
    'uses'=>'RegistrationController@getFile',
    'as'=>'file'
    ]);

Route::post('signup',[
    'uses'=>'RegistrationController@postSignUp',
    'as'=>'signup'
    ]);
    
Route::get('dashboard',[
    'uses'=>'RegistrationController@getDashboard',
    'as'=>'dashboard'
    ]);

Route::get('logout', [
	'uses'=>'RegistrationController@doLogout',
	'as'=>'logout'
	]);
Route::post('signin',[
    'uses'=>'RegistrationController@postSignIn',
    'as'=>'signin'
    ]);

Route::post('form/(Auth::user()->username)',[
    'uses'=>'RegistrationController@postTable',
    'as'=>'form/(Auth::user()->username)'
    ]);
Route::get('comment',[
    'uses'=>'RegistrationController@getCommentform',
    'as'=>'comment'
    ]);

Route::controller('/','RegistrationController');
});

