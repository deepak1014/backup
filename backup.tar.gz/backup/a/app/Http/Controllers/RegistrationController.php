<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Hash;

use App\Http\Requests;

use App\User;

use App\Message;

use App\Feedback;





class RegistrationController extends Controller
{

    public function getSignup()
    {
        return view('sign_up');
    }
    public function getSignin()
    {
        return view('sign_in');
    }
    public function getForm()
    {
        $data['posts']=Post::all();
        return view('form',$data);
    }
    public function displayForm()
    {
        return view('form');
    }
    
    public function postSignUp(Request $request)
    {
            $username=$request['username'];
	    	$password=Hash::make($request['password']);
           
	    	$email=$request['email'];

	    	$data=new User();
            $data->username=$username;
	    	$data->password=$password;
	    	$data->email=$email;
            $path=public_path('/upload');
            $name=base_convert(time(),10,36).'_'.$request->image->getClientOriginalName();
            $request->image->move($path,$name);
            $data->image=$name;
            $data->save();
            return redirect()->back();
    }
  public function postSignIn(Request $request)
    {



    	$username=$request['username'];
	    $password=$request['password'];
        
         
        
	    if(Auth::attempt(['username'=>$username,'password'=>$password]))
    	{
            return redirect()->route('dashboard');
    	}
    	return redirect()->back();
    }

public function doLogout()
    { \Auth::logout(); 
    return redirect('/'); } 

public function getDashboard()
    {
        $data['posts']=User::all();
    	return view('dashboard',$data);
    }
    public function getDisplay()
    {
        return view('form');
    }

 

public function postTable(Request $request)
{
    $data=new Post;
    $data->title=$request->title;
    $data->post=$request->post;
    $data->created_by=(Auth::user()->username);
    $data->image=(Auth::user()->image);
    $data->save();
    return redirect()->back();
}

public function getDelete($id)
{
    $data=Post::find($id);
    $data->delete();
    return redirect()->back();
}
public function getComment($id)
{
    $data['post']=Post::find($id);
    return view('comment',$data);
}
public function postFeedback(Request $request)
{
    $data=new Feedback;
    $data->review=$request->comment;
    $data->username=(Auth::user()->username);
    $data->save();
    return redirect()->back();
}
public function getId($id)
{
    $user = User::find($id);

    $data['detail']=$user AND  $data['messages']=$user->messages();

    return view('new_form',$data);
}
public function postStore(Request $request,$id)
{   $data=new Message;
    $data->title=$request->title;
    $data->post=$request->post;
    $data->receiver_id=$id;
    $data->created_by=Auth::user()->username;
    $data->save();
    return redirect()->back();
    
}
public function getCommentform()
{
    return view('comment');
}

 
}







