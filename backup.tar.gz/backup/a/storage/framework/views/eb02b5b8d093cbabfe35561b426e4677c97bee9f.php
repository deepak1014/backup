<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body>
<div class="container">
<div class="row">
<div class="col-sm-6">
<?php if($errors->any()): ?>
<h4><?php echo e($errors->first()); ?></h4>
<?php endif; ?>

<form action="<?php echo e(route('signin')); ?>" method="post" >
<?php echo csrf_field(); ?>

<input type="text" class="form-control" name="username" placeholder="Username" required><br/>
<input type="password" class="form-control" name="password" placeholder="Password" required><br/>
<input type="submit" name="submit" class="btn btn-primary" value="Sign In">
</form>
</div>
</div>
