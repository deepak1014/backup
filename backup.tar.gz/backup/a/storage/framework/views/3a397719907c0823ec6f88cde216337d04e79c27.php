<img src="\upload\<?php echo e($detail->image); ?>" height="100px" width="100px">

<?php echo e($detail->username); ?>


<br/>

<?php echo e($detail->email); ?>


<br>

<?php foreach($messages as $message): ?>    
    <?php echo e($message->title); ?>

    <?php echo e($message->post); ?>

<?php endforeach; ?>

<form action="/store/<?php echo e($detail->id); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input type="text" name="title" class="form-control" placeholder="title" required>
    <br/>
    <textarea rows="4" cols="4" name="post" class="form-control" placeholder="post" required></textarea>
    <br/>
    <input type="submit" name="submit" class="btn btn-primary" value="submit">
</form>