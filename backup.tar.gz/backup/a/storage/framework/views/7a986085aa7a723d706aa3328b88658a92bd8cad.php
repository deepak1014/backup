<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
<div class="container">
<div class="row">
<div class="col-sm-11">
<form action="/(Auth::user()->username)" method="post">
<?php echo csrf_field(); ?>

<input type="text" name="title" class="form-control" placeholder="title" required><br/>
<textarea rows="4" cols="4" name="post" class="form-control" placeholder="post" required></textarea><br/>
<input type="submit" name="submit" class="btn btn-primary" value="submit">
</form>

</div>
</div>
</div>