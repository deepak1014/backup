<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body>
<div class="container">
<div class="row">
<div class="col-sm-6">	
<form action="<?php echo e(route('signup')); ?>" method="post" enctype="multipart/form-data" id="sign_up">
<?php echo csrf_field(); ?>

<input type="text" name="username" class="form-control" placeholder="Username"><br/>
<input type="password" name="password" class="form-control" placeholder="Password"><br/>
<input type="file" name="image"><br/>
<input type="text" name="email" class="form-control" placeholder="Email"><br/>
<input type="submit" name="submit" value="Sign Up" class="btn btn-primary" >
</form>
</div>
<div class="col-sm-6">
<form action="<?php echo e(route('signin')); ?>" method="post" >
<?php echo csrf_field(); ?>

<input type="text" class="form-control" name="username" placeholder="Username"><br/>
<input type="password" class="form-control" name="password" placeholder="Password"><br/>
<input type="submit" name="submit" class="btn btn-primary" value="Sign In">
</form>
</div>

