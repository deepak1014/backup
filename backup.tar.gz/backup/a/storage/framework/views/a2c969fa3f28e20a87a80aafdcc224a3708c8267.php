

<form action="/table/<?php echo e($edit_data->id); ?>" method="post">
<?php echo csrf_field(); ?>

<?php if(isset($edit_data)): ?>

<input type="hidden" id="id" value="<?php echo e($edit_data->id); ?>">

<?php endif; ?>
<input type="text" name="title" class="form-control"><br/>
<textarea rows="4" cols="4" name="post" class="form-control"></textarea><br/>
<input type="submit" name="update" class="btn btn-primary" value="submit">
</form>
