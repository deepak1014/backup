<img src="\upload\<?php echo e($detail->image); ?>" height="100px" width="100px"><br/>
<?php echo e($detail->username); ?><br/>
<?php echo e($detail->email); ?><br/>
