<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
<div class="container">

<div class="row">
<div class="col-sm-4">
<img src="\upload\<?php echo e((Auth::user()->image)); ?>" height="100px" width="100px">
<p>Welcome <br/><?php echo e(isset(Auth::user()->username) ? Auth::user()->username
:Auth::user()->password); ?></p> <a href="<?php echo e(route('logout')); ?>">Logout</a>
	</div>
<div class="col-sm-4">
	 <?php foreach($posts as $post): ?>
<img src="\upload\<?php echo e($post->image); ?>" height="50px" width="50px"><br/>

 <b>Title
:</b><?php echo e($post->title); ?><br/> <b>Post :</b><?php echo e($post->post); ?><br/> <b>Created At
:</b><?php echo e($post->created_at); ?><br/>
 <b>Created By
:</b><?php echo e($post->created_by); ?><br/><br/>
<a href="/delete/<?php echo e($post->id); ?>">delete</a>
 <a href="/comment/<?php echo e($post->id); ?>">comment</a>
<hr>
 <?php endforeach; ?>
<form action="/(Auth::user()->username)" method="post">
<?php echo csrf_field(); ?>

<input type="text" name="title" class="form-control" placeholder="title" required><br/>
<textarea rows="4" cols="4" name="post" class="form-control" placeholder="post" required></textarea><br/>
<input type="submit" name="submit" class="btn btn-primary" value="submit">
</form>
</div>
</div>