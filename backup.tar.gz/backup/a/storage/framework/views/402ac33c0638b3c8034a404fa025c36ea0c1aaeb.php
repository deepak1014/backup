<html>
<head><title>website</title>
<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
</head>
<body>
<div class="container">
<div class="row">
<div class="col-sm-6">
<form action="<?php echo e(route('signup')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>


<input type="text" name="username" class="form-control" placeholder="Username" required><br/>
<input type="password" name="password" class="form-control" placeholder="Password" required><br/>
<input type="text" name="email" class="form-control" placeholder="Email" required><br/>
<input type="file" name="image"><br/>
<input type="submit" name="submit" value="Sign Up" class="btn btn-primary" >
</form>
</div>
