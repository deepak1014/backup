<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
<div class="container">
<div class="row">
<div class="col-sm-4">
<img src="\upload\<?php echo e((Auth::user()->image)); ?>" height="100px" width="100px">
<p>Welcome <br/><?php echo e(isset(Auth::user()->username) ? Auth::user()->username :Auth::user()->password); ?></p>
<a href="<?php echo e(route('logout')); ?>">Logout</a>
</div>
<div class="col-sm-4">
<h3>Registered User</h3><br/>

<?php foreach($posts as $post): ?>
<img src="\upload\<?php echo e($post->image); ?>" height="100px" width="100px"><br/>
<p></p><a href="id/<?php echo e($post->id); ?>">send message</a><br/><p><?php echo e($post->email); ?></p><br/><hr>
<?php endforeach; ?>
</div>
</div>