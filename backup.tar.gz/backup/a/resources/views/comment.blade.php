

<img src="\upload\{{$detail->image}}" height="100px" width="100px">

{{$detail->username}}

<br/>

{{$detail->email}}

<br>

{{$messages->body}}

<form action="/store/{{$detail->id}}" method="post">
    {!!csrf_field()!!}
    <input type="text" name="title" class="form-control" placeholder="title" required>
    <br/>
    <textarea rows="4" cols="4" name="post" class="form-control" placeholder="post" required></textarea>
    <br/>
    <input type="submit" name="submit" class="btn btn-primary" value="submit">
</form>