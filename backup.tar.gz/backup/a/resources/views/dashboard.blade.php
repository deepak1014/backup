<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">
<div class="container">
<div class="row">
<div class="col-sm-4">
<img src="\upload\{{(Auth::user()->image)}}" height="100px" width="100px">
<p>Welcome <br/>{{{isset(Auth::user()->username) ? Auth::user()->username :Auth::user()->password}}}</p>
<a href="{{ route('logout') }}">Logout</a>
</div>
<div class="col-sm-4">
<h3>Registered User</h3><br/>

@foreach($posts as $post)
<img src="\upload\{{$post->image}}" height="100px" width="100px"><br/>
<p></p><a href="id/{{$post->id}}">send message</a><br/><p>{{$post->email}}</p><br/><hr>
@endforeach
</div>
</div>