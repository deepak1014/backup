<link href="\bootstrap\css\bootstrap.min.css" rel="stylesheet">
<link href="\bootstrap\css\stylesheet.css" rel="stylesheet">

<form action="{{route('form/review')}}" method="post">
{!!csrf_field()!!}
<input type="text" name="title" class="form-control" placeholder="title" required><br/>
<textarea rows="4" cols="4" name="post" class="form-control" placeholder="post" required></textarea><br/>
<input type="submit" name="submit" class="btn btn-primary" value="submit">
</form>
