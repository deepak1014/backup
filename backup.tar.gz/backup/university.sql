-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 05, 2016 at 12:10 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Table structure for table `About`
--

CREATE TABLE `About` (
  `id` int(10) UNSIGNED NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `About`
--

INSERT INTO `About` (`id`, `text`, `created_at`, `updated_at`) VALUES
(1, '"The University has been incorporated for the purpose, among others, of making provision for imparting education in Arts, Letters, Science and the learned professions and of furthering advancement of learning, the prosecution of original research, with power to appoint University Professors, Readers and Lecturers, to hold and manage educational endowments, to erect, equip and maintain University colleges, libraries, laboratories and museums, to making regulations relating to the residence and conduct of students and to do all such acts as tend to promote study and research". ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Blog`
--

CREATE TABLE `Blog` (
  `id` int(10) UNSIGNED NOT NULL,
  `blog_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `blog_post` text COLLATE utf8_unicode_ci NOT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Blog`
--

INSERT INTO `Blog` (`id`, `blog_title`, `blog_post`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'University is taking all student on tour', 'University is taking all student on tour for 12 days.The tour can be of anywhere in india.University is taking all student on tour for 12 days.The tour can be of anywhere in india.', 'Raj Sharma', '2016-08-31 18:30:00', '2016-08-31 18:30:00'),
(2, 'Result is going to be declared in few days', 'All result will be declared very soon.Keep visiting university website for updates.', 'Vikas Sharma', '2016-08-31 18:30:00', '2016-08-31 18:30:00'),
(3, 'All student keep monitoring university website ', 'All student keep monitoring university website for updates.All student keep monitoring university website for updates.', 'Akash Sharma', '2016-08-31 18:30:00', NULL),
(4, 'University will be starting new courses very soon', 'University will be starting new courses very soon.University will be starting new courses very soon.', 'Vikas Sharma', '2016-08-31 18:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Data`
--

CREATE TABLE `Data` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Data`
--

INSERT INTO `Data` (`id`, `name`, `email`, `gender`, `language`, `state`, `created_at`, `updated_at`) VALUES
(1, 'raman sharma', 'a@gmail.com', 'Male', 'english', 'rajasthan', '2016-09-05 00:14:18', '2016-09-05 00:14:18'),
(2, 'raman sharma', 'a@gmail.com', 'Male', 'hindi', 'rajasthan', '2016-09-05 00:16:30', '2016-09-05 00:16:30'),
(3, 'raman sharma', 'a@gmail.com', 'Male', 'hindi', 'madhya pradesh', '2016-09-05 00:35:32', '2016-09-05 00:35:32'),
(4, 'raman sharma', 'a@gmail.com', 'Male', 'english,hindi', 'madhya pradesh', '2016-09-05 01:09:51', '2016-09-05 01:09:51'),
(5, 'raman sharma', 'a@gmail.com', 'Male', 'english,hindi', 'rajasthan', '2016-09-05 01:10:40', '2016-09-05 01:10:40');

-- --------------------------------------------------------

--
-- Table structure for table `English`
--

CREATE TABLE `English` (
  `id` int(10) UNSIGNED NOT NULL,
  `s_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rapid_english` int(11) NOT NULL,
  `english_grammer` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `English`
--

INSERT INTO `English` (`id`, `s_name`, `rapid_english`, `english_grammer`, `created_at`, `updated_at`) VALUES
(1, 'Raj Sharma', 99, 99, NULL, NULL),
(2, 'Vikas Sharma', 99, 99, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Index`
--

CREATE TABLE `Index` (
  `id` int(10) UNSIGNED NOT NULL,
  `left_text` text COLLATE utf8_unicode_ci NOT NULL,
  `middle_text` text COLLATE utf8_unicode_ci NOT NULL,
  `right_text` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Index`
--

INSERT INTO `Index` (`id`, `left_text`, `middle_text`, `right_text`, `created_at`, `updated_at`) VALUES
(1, 'Born on 1st April, 1937, at Calcutta, Shri M. Hamid Ansari, obtained a Masters Degree in Political Science from Aligarh Muslim University.', 'Under the able guidance and leadership of Honorable Chief Minister of Punjab, Panjab University, Chandigarh is celebrating 125th birth Anniversary of Bharat Ratna – Dr. B. R. Ambedkar and in this context Panjab University in collaboration with Punjab Government is organizing one day National Seminar on 30th August 2016 at 10.30 a.m.at Law Auditorium, Panjab University, Chandigarh. Among the dignitaries is H.E Governor of Bihar. Sh. Ram Nath Kovind Ji, H.E Governor of Haryana Sh. Kaptan Singh Solanki, Hon’ble Speaker Vidhan Sabha S.Charanjit Singh Atwal, Chaudhary Zulfkar Ali Hon’ble minister for Consumer Affairs & Public Distribution and Legal metrology, Government Of Jammu & Kashmir, cabinet ministers and many well known scholars, academicians and Government officials are expected to participate in this National Seminar on “Parliamentary Democracy: Views of Dr.Babasaheb Ambedkar”.', 'The main objectives of this seminar are to deliberate upon philosophy and ideas of Dr. Ambedkar on Parliamentary Democracy and its operational mechanism and also to discuss and evaluate success and failures of India’s Parliamentary Democracy.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2016_08_29_065818_create_Index_table', 1),
('2016_08_29_074921_create_About_table', 2),
('2016_08_29_093910_create_Student_activities_table', 3),
('2016_08_29_101527_create_English_result', 4),
('2016_08_29_110942_create_Login_table', 5),
('2016_08_29_113434_create_User_table', 6),
('2016_08_29_121712_create_Signup_table', 7),
('2016_09_01_061235_create_Blog_table', 8),
('2016_09_05_053232_create_Data_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Signup`
--

CREATE TABLE `Signup` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Signup`
--

INSERT INTO `Signup` (`id`, `username`, `password`, `email`, `image`, `remember_token`, `created_at`, `updated_at`) VALUES
(8, 'raman sharma', '$2y$10$5U75FEkIxzx8clxmyzyCK.U.ZTM00TDEjJCXJSEri9OSTqoZAShYW', 'a@gmail.com', 'ocpylr_ocpyhj_image.jpeg', '1iOAI6v6uiNU5ToLAVSPamHGORN1mfctPjxM038kSkkz2Oy2Y3nS96m8qEhG', '2016-08-30 05:31:03', '2016-09-02 01:26:49'),
(9, 'vikas sharma', '$2y$10$01L4Gdcr6s1KBWsG5OIDBuS1bZP6adBLkBtX9lC.y7zDFtpM57Djq', 'a@gmail.com', 'ocq5p6_ocpyhj_image.jpeg', '8lsk9QcFlkM5LUsuICehDvQ9dMT4yvbxXpNcbowudUa2Uqeakh0ysreJPnqG', '2016-08-30 08:04:18', '2016-09-05 01:22:07'),
(10, 'raman sharma', '$2y$10$07krlwFxaOYGRD3Sa.XJne9C7bvjonvKICoC/jU9ih1npo6phYae2', 'a@gmail.com', 'octpx2_ocq5p6_ocpyhj_image.jpeg', NULL, '2016-09-01 06:13:50', '2016-09-01 06:13:50');

-- --------------------------------------------------------

--
-- Table structure for table `Student_Activities`
--

CREATE TABLE `Student_Activities` (
  `id` int(10) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Student_Activities`
--

INSERT INTO `Student_Activities` (`id`, `image`, `created_at`, `updated_at`) VALUES
(1, 'image1.jpeg', NULL, NULL),
(2, 'image2.jpg', NULL, NULL),
(3, 'image3.jpeg', NULL, NULL),
(4, 'image4.jpeg', NULL, NULL),
(5, 'image5.jpeg', NULL, NULL),
(6, 'image6.jpeg', NULL, NULL),
(7, 'image7.jpeg', NULL, NULL),
(8, 'image8.jpg', NULL, NULL),
(9, 'image9.jpeg', NULL, NULL),
(10, 'image10.jpeg', NULL, NULL),
(11, 'image11.jpeg', NULL, NULL),
(12, 'image12.jpeg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`id`, `username`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'raj sharma', 'a', NULL, NULL, NULL),
(2, 'vikas sharma', 'a', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `About`
--
ALTER TABLE `About`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Blog`
--
ALTER TABLE `Blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Data`
--
ALTER TABLE `Data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `English`
--
ALTER TABLE `English`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Index`
--
ALTER TABLE `Index`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `Signup`
--
ALTER TABLE `Signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Student_Activities`
--
ALTER TABLE `Student_Activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `About`
--
ALTER TABLE `About`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Blog`
--
ALTER TABLE `Blog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Data`
--
ALTER TABLE `Data`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `English`
--
ALTER TABLE `English`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Index`
--
ALTER TABLE `Index`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Signup`
--
ALTER TABLE `Signup`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `Student_Activities`
--
ALTER TABLE `Student_Activities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
